from django.contrib import admin
from analysis.models import Document

# Register your models here.
@admin.register(Document)
class DocumentAdmin(admin.ModelAdmin):
    list_display = ("id","document","uploaded","user")