from django.shortcuts import get_object_or_404

from analysis.models import Document
from analysis.serializers import DocumentSerializer

import pandas as pd
import youtube_dl

class UploadService:
    def __init__(self,user):
        self.user = user
        #self.request= request

    def isDocumentAvailable(self):
        return Document.objects.filter(user=self.user).exists()

    def uploadFile(self,request):
        if not self.isDocumentAvailable():
            return DocumentSerializer(context={'request':request},data=request.data)
        else:
            document = get_object_or_404(Document,user=self.user)
            return DocumentSerializer(document,context={'request':request},data=request.data)

    def viewDocumentt(self):
        if self.isDocumentAvailable():
            document = get_object_or_404(Document, user=self.user)
            return DocumentSerializer(document)
        else:
            return None


class Analyze:
    def __init__(self,user):
        self.user = user
        self.uploadService = UploadService(user)

    def downloadYoutubeData(self):
        document = get_object_or_404(Document,user=self.user)
        doc = pd.read_json(document.document)
        videos = doc.titleUrl
        ydl_opts = {}
        data = []

        for v in videos:
            try:
                with youtube_dl.YoutubeDL(ydl_opts) as ydl:
                    meta = ydl.extract_info(v, download=False)
            except:
                print("exception occurs - video could not be downloaded")
            data.append(meta)
        print(data)


'''
        ydl_opts = {}

        with youtube_dl.YoutubeDL(ydl_opts) as ydl:
            meta = ydl.extract_info(
                'https://www.youtube.com/watch?v=9bZkp7q19f0', download=False)

        
        # command line to extract data from youtube
        cmd = f'youtube-dl --skip-download
        urls = [u.get('href') for u in soup.find_all('a')]
        videos = [u for u in urls if 'www.youtube.com/watch' in u]
        url_path = self.path / 'urls.txt'
        url_path.write_text('\n'.join(videos))
        print(f'Urls extracted. Downloading data for {len(videos)} videos now.')
        output = os.path.join(self.raw, '%(autonumber)s')
        cmd = f'youtube-dl -o "{output}" --skip-download --write-info-json -i -a {url_path}'
        p = sp.Popen(cmd, stdout=sp.PIPE, stderr=sp.STDOUT, shell=True)
        line = True
        while line:
            line = p.stdout.readline().decode("utf-8").strip()
            print(line)'''

