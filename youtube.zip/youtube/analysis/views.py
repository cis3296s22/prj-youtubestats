import os.path
import pandas as pd

from django.shortcuts import render
from django.shortcuts import get_object_or_404
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.parsers import FileUploadParser,JSONParser, MultiPartParser
import json
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from analysis.models import Document
from analysis.serializers import UserSerializer, DocumentSerializer
from rest_framework.permissions import IsAuthenticated
from analysis.services import UploadService, Analyze

# Create your views here.
class uploadWatchHistory(APIView):
    parser_classes = [MultiPartParser]
    permission_classes = [IsAuthenticated]

    def get(self, requeest):
        data= Analyze(self.request.user).downloadYoutubeData()
        return Response({"result":"testing"})

    def post(self, request, *args, **kwargs):
        serializer = UploadService(self.request.user).uploadFile(request)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)





        '''
        doc = get_object_or_404(Document,user=self.request.user)
        serializer = DocumentSerializer(doc)
        df = pd.read_json(doc.document)
        print(df)'''

        '''
        #file = request.data['file']
        #data={}
        #data["document"] = file
        user = self.request.user
        data = request.data
        if not Document.objects.filter(user=user).exists():
            serializer = DocumentSerializer(context={'request':request},data=data)
            print(serializer)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        else:
            document = get_object_or_404(Document,user=user)
            serializer = DocumentSerializer(document,context={'request':request},data=data)
            if serializer.is_valid():
                serializer.save()
                return Response({"result":"working"})
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)'''


        '''
        upload = request.data.get('file',None)
        fss = FileSystemStorage()
        fileUpload = fss.save(upload.name, upload)
        #file = fss.url(fileUpload)
        if upload:
            df = pd.read_json("http://localhost:3000/media/watch-history.json")
            print(df.titleUrl)
            return Response({"message":"File is received"}, status=status.HTTP_201_CREATED)
        else:
            return Response({"message":"File is not received"}, status=status.HTTP_404_NOT_FOUND)'''
