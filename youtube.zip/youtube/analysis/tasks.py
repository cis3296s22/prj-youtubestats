from celery import shared_task
from analysis.serializers import UserSerializer, DocumentSerializer
import json

@shared_task
def saveWatchHistory(serializer):
        if serializer.is_valid():
            serializer.save()

